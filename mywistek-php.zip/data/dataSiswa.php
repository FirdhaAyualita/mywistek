<?php

	require "../connect.php";

	$response = array();
	$nis = $_GET['nis'];

	$sql = mysqli_query($conn, "SELECT * FROM datasiswa WHERE nis='$nis'");
	$result =mysqli_fetch_array($sql);
	$dataJurusan = $result['jurusan'];
	$jurusan = mysqli_query($conn, "SELECT * FROM jurusan WHERE kode_jurusan='$dataJurusan'");
	$resultJurusan =mysqli_fetch_array($jurusan);
	if (isset($result)) {
			// code...
			$response['value'] = 1;
			$response['message'] = 'Ambil Data Berhasil';
			$response['nama'] = $result['nama'];
			// $response['jurusan'] = $result['jurusan'];
			$response['jurusan'] = $resultJurusan['nama_jurusan'];
			$response['kode_jurusan'] = $resultJurusan['kode_jurusan'];
			$response['kelas'] = $result['kelas'];
			$response['jenjang'] = $result['jenjang'];
			$response['semester'] = $result['semester'];
			$response['nis'] = $result['nis'];
			$response['foto'] = $result['foto'];
			echo json_encode($response);
		}else{
			$response['value'] = 0;
			$response['message'] = 'Ambil Data Gagal';
			echo json_encode($response);
		}



// 	$response = array();

// 	$sql = mysqli_query($conn, "SELECT a.*, b.nama FROM datasiswa a left join user b on a.idUser = b.id");
	
// 	while ($a = mysqli_fetch_array($sql)) {
// 		// code...
// 		$b['id'] = $a['id'];
// 		$b['idUser'] = $a['idUser'];
// 		$b['nama'] = $a['nama'];
// 		$b['jk'] = $a['jk'];
// 		$b['nomor_hp'] = $a['nomor_hp'];
// 		$b['jurusan'] = $a['jurusan'];
// 		$b['jenjang'] = $a['jenjang'];
// 		$b['kelas'] = $a['kelas'];
// 		$b['foto'] = $a['foto'];

// 		array_push($response, $b);

// 	}
// echo json_encode($response);

	// if ($_SERVER['REQUEST_METHOD']=="POST") {
	// 	# code..
	// 	$response = array();
	// 	$username = $_POST['username'];
	// 	$password = md5($_POST['password']);

	// 	$cek = "SELECT * FROM user WHERE username = '$username' and password = '$password'";
	// 	$result = mysqli_fetch_assoc(mysqli_query($conn, $cek));

	// 	if (isset($result)) {
	// 		// code...
	// 		$response['value'] = 1;
	// 		$response['message'] = 'Login Berhasil';
	// 		$response['username'] = $result['username'];
	// 		$response['nama'] = $result['nama'];
	// 		$response['id'] = $result['id'];
	// 		echo json_encode($response);
	// 	}else{
	// 		$response['value'] = 0;
	// 		$response['message'] = 'Login Gagal';
	// 		echo json_encode($response);
	// 	}

		
	// }

?>