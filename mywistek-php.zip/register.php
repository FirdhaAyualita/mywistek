<?php

	require "connect.php";

	if ($_SERVER['REQUEST_METHOD']=="POST") {
		# code..
		$response = array();
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$nama = $_POST['nama'];

		$cek = "SELECT * FROM user WHERE username = '$username'";
		$result = mysqli_fetch_assoc(mysqli_query($conn, $cek));

		if (isset($result)) {
			// code...
			$response['value'] = 2;
			$response['message'] = 'Username Telah Digunakan';
			echo json_encode($response);
		}else{
			$insert = "INSERT INTO user VALUE(NULL, '$username','$password','1','$nama','1',NOW())";
			if (mysqli_query($conn, $insert)) {
				// code...
				$response['value'] = 1;
				$response['message'] = 'Berhasil Didaftarkan';
				echo json_encode($response);
			} else {
				// code...
				$response['value'] = 0;
				$response['message'] = 'Gagal Didaftarkan';
				echo json_encode($response);
			}

		}

		
	}

?>