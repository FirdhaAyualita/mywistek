<?php

	require "../connect.php";

	$response = array();
	$jurusan = $_GET['jurusan'];
	$kelas = $_GET['kelas'];
	$semester = $_GET['semester'];


	$sql = mysqli_query($conn, "SELECT * FROM mata_kuliah WHERE semester = '$semester' AND kelas = '$kelas' AND jurusan = '$jurusan' AND hari = 'selasa'");
	while ($a = mysqli_fetch_array($sql)) {
		// code...
		$dataJurusan = $a['jurusan'];
		$jurusan = mysqli_query($conn, "SELECT * FROM jurusan WHERE kode_jurusan='$dataJurusan'");
		$resultJurusan =mysqli_fetch_array($jurusan);
		$b['kode_mtk'] = strtoupper($a['kode_mtk']);
		$b['nama_mtk'] = strtoupper($a['nama_mtk']);
		$b['jam_mulai'] = date('H:i', strtotime($a['jam_mulai']));
		$b['jam_akhir'] = date('H:i', strtotime($a['jam_akhir']));
		$b['nama_dosen'] = $a['nama_dosen'];
		$b['sks'] = $a['sks'];
		$b['no_ruang'] = $a['no_ruang'];
		$b['kel_praktek'] = $a['kel_praktek'];
		$b['hari'] = $a['hari'];
		$b['kelas'] = strtoupper($a['kelas']);
		$b['semester'] = $a['semester'];
		$b['jurusan'] = $resultJurusan['nama_jurusan'];
		array_push($response, $b);
		
	}
	echo json_encode($response);
			
?>

