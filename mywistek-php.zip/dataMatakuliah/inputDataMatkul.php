<?php

	require "../connect.php";

	if ($_SERVER['REQUEST_METHOD']=="POST") {
		# code..
		$response = array();
		$kode_mtk = $_POST['kode_mtk'];
		$nama_mtk = $_POST['nama_mtk'];
		$jam_mulai = $_POST['jam_mulai'];
		$jam_akhir = $_POST['jam_akhir'];
		$nama_dosen = $_POST['nama_dosen'];
		$sks = $_POST['sks'];
		$no_ruang = $_POST['no_ruang'];
		$kel_praktek = $_POST['kel_praktek'];
		$jurusan = $_POST['jurusan'];
		$semester = $_POST['semester'];
		$kelas = $_POST['kelas'];
		$hari = $_POST['hari'];


		$insert = "INSERT INTO mata_kuliah VALUE(NULL, '$kode_mtk','$nama_mtk','$jam_mulai','$jam_akhir','$nama_dosen','$sks','$no_ruang','$kel_praktek','$jurusan','$semester','$kelas','$hari')";
		if (mysqli_query($conn, $insert)) {
			// code...
			$response['value'] = 1;
			$response['message'] = 'Data Mata Kuliah Berhasil Ditambahkan';
			echo json_encode($response);
		} else {
			// code...
			$response['value'] = 0;
			$response['message'] = 'Data Mata Kuliah Gagal Ditambahkan';
			echo json_encode($response);
		}
		
	}

?>