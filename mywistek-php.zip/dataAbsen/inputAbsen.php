<?php

	require "../connect.php";

	if ($_SERVER['REQUEST_METHOD']=="POST") {
		# code..
		$response = [];
		$nis = $_POST['nis'];
		$kode_mtk = $_POST['kode_mtk'];
		$jurusan = $_POST['jurusan'];
		$semester = $_POST['semester'];
		$kelas = $_POST['kelas'];
		$keterangan = $_POST['keterangan'];

		$query = mysqli_query($conn, "SELECT max(pertemuan) as pertemuanTerbesar FROM absen WHERE semester = '$semester' AND kelas = '$kelas' AND jurusan = '$jurusan' AND kode_mtk = '$kode_mtk' AND nis = '$nis'");
		$data = mysqli_fetch_array($query);
		$kodePertemuan = $data['pertemuanTerbesar'];
		 
		$urutan = (int) substr($kodePertemuan, 9, 2);
		 
		$urutan++;
		 
		$huruf = "Pertemuan";
		$kodePertemuan = $huruf .  sprintf("%02d", $urutan);
		$hasil = ltrim(substr($kodePertemuan, 9, 2),"0");
		$hasilPertemuan = $huruf . " " . $hasil;

		$insert = "INSERT INTO absen VALUE(NULL, '$nis','$kode_mtk','$jurusan','$semester','$kelas','$kodePertemuan','$keterangan',NOW())";
		$result = mysqli_query($conn, $insert);
		if ($result) {
			// code...
			$response['value'] = 1;
			$response['message'] = 'Absensi Berhasil Ditambahkan';
		} else {
			// code...
			$response['value'] = 0;
			$response['message'] = 'Absensi Gagal Ditambahkan';
		}
		print(json_encode($response));
		
	}

?>