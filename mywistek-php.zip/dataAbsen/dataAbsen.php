<?php

	require "../connect.php";

	$response = array();
	$jurusan = $_GET['jurusan'];
	$kelas = $_GET['kelas'];
	$semester = $_GET['semester'];
	$kode_mtk = $_GET['kode_mtk'];
	$nis = $_GET['nis'];
	// $jurusan = 'tkj';
	// $kelas = 'X-TJKT';
	// $semester = '2';
	// $kode_mtk = 'mtk';
	// $nis = '19200560';
	

	$sql = mysqli_query($conn, "SELECT * FROM absen WHERE semester = '$semester' AND kelas = '$kelas' AND jurusan = '$jurusan' AND kode_mtk = '$kode_mtk' AND nis = '$nis'");
	while ($a = mysqli_fetch_array($sql)) {
		// code...
		$dataMatkul = $a['kode_mtk'];
		$matkul = mysqli_query($conn, "SELECT * FROM mata_kuliah WHERE kode_mtk='$dataMatkul'");
		$resultMatkul =mysqli_fetch_array($matkul);
		$b['waktu_absen'] = date('d M Y',strtotime($a['waktu_absen']));
		$b['keterangan'] = $a['keterangan'];
		// $b['pertemuan'] = $a['pertemuan'];
		$hasil = ltrim(substr($a['pertemuan'], 9, 2),"0");
		$b['pertemuan'] = "Pertemuan " . $hasil;
		$b['hariEnglish'] = date('l',strtotime($a['waktu_absen']));
		$b['hari'] = date('l',strtotime($a['waktu_absen']));
		switch ($b['hari']) {
			case"Sunday":$b['hari']="Min";break;
			case"Monday":$b['hari']="Sen";break;
			case"Tuesday":$b['hari']="Sel";break;
			case"Wednesday":$b['hari']="Rab";break;
			case"Thursday":$b['hari']="Kam";break;
			case"Friday":$b['hari']="Jum";break;
			case"Saturday":$b['hari']="Sab";break;
		}
		$b['waktuKuliah'] = date('H:i', strtotime($resultMatkul['jam_mulai'])) . ' s/d '.date('H:i', strtotime($resultMatkul['jam_akhir']));

		// $b['jam_mulai'] = date('H:i', strtotime($a['jam_mulai']));
		// $b['jam_akhir'] = date('H:i', strtotime($a['jam_akhir']));
		array_push($response, $b);
		
	}
	echo json_encode($response);



			
?>

